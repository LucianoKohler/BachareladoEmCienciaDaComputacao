public interface IOperacaoInteira {
  int executar(int v1, int v2);
}