

public class Soma implements IOperacaoInteira {
  public int executar(int v1, int v2) {
    return v1 + v2;
  }
}
