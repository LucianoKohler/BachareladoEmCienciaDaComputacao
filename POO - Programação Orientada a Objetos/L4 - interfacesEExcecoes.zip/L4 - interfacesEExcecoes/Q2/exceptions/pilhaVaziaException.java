package exceptions;

public class pilhaVaziaException extends Exception {
    public pilhaVaziaException() {
        super("Erro: A pilha deste juíz está vazia");
    }
  
}
