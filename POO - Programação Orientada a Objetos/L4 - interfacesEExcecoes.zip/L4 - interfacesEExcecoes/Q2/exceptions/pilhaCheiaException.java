package exceptions;

public class pilhaCheiaException extends Exception {
    public pilhaCheiaException() {
        super("Erro: A pilha deste juíz está cheia");
    }
  
}
